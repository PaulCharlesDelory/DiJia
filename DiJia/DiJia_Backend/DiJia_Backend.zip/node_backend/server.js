const express = require('express');
const http = require('http');
const axios = require('axios');
const { Server } = require('socket.io');

const port = process.env.PORT || 3000;
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

io.on('connection', (socket) => {
  console.log('Client connecté sur port', port);

  socket.on('message', async (msg) => {
    try {
      const response = await axios.post('http://fastapi:8000/api/message', {
        user_id: socket.id,
        content: msg
      });
      socket.emit('message', response.data.response);
    } catch (err) {
      console.error(err.message);
      socket.emit('message', 'Erreur du serveur IA.');
    }
  });
});

server.listen(port, () => {
  console.log(`Serveur Node.js lancé sur le port ${port}`);
});