from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Message(BaseModel):
    user_id: str
    content: str

@app.post("/api/message")
async def message_handler(msg: Message):
    return {
        "response": f"Réponse IA simulée à '{msg.content}' pour {msg.user_id}",
        "points": 10
    }

@app.get("/api/ping")
def ping():
    return {"ping": "pong"}